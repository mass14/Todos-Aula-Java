package oo.exercicios;

public class CasaFeliz {

	public static void main(String[] args) {
		Casa casa = new Casa();
		casa.pinta("verde");
		
		Porta p1 = new Porta();
		p1.pinta("vermelho");
		p1.abre();
		casa.setPorta1(p1);
		
		casa.setPorta2(new Porta());
		casa.getPorta2().abre();
		casa.getPorta2().pinta("amarelo");
		
		casa.getPorta1().fecha();
		System.out.println(casa.quantasPortasEstaoAbertas());
		System.out.println(casa.totalDePortas());

	}

}
